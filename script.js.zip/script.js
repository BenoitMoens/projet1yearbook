const wildersArray = [{
    name: "Marouan",
    type: "trainee",
    origne: "Belgium",
    html: "bien"
}, {
    name: "Benoit",
    type: "trainee",
    origne: "Belgium",
    html: "bien"
}, {
    name: "Steve",
    type: "trainee",
    origne: "Belgium",
    html: "bien"
}];


// 1 - Identifier avec JS le noeud parent dans lequel je veux inserer des noeuds enfants
const wildersParentDiv = document.getElementById('people-list')
console.log(wildersParentDiv);
// 2 - Inserer en JS un noeud enfant à ce parent : 

//3 - Realiser une boucle de wilder qui insere le code précédent avec la data correspondante.

for (let i = 0; i < wildersArray.length; i++); {
    //  trouver un moyen avec appenChild pour afficher chaque personne
    document.getElementById('people-list').innerHTML =
        `<article id="Marouan" class="carte">
 <h2>#01 Marouan</h2>
 <img src="img/Marouan.jpg" class="img-profile">
 <div class="proprietes">
     <div>Type:</div>
     <div>Trainee</div>
     <div>Origin:</div>
     <div>Belgium</div>
     <div>HTML</div>
     <div> <img src="icons8-pokéball-48.png" alt="Red Pokeball">
         <img src="icons8-pokéball-48.png" alt="Red Pokeball">
        <img src="icons8-pokéball-48.png" alt="Red Pokeball">
        <img src="icon-disabled.png" alt="Black Pokeball">
     </div>
     <div>CSS</div>
     <div> <img src="icons8-pokéball-48.png" alt="Red Pokeball">
         <img src="icons8-pokéball-48.png" alt="Red Pokeball">
         <img src="icon-disabled.png" alt="Black Pokeball">
         <img src="icon-disabled.png" alt="Black Pokeball">
     </div>
     <div>Javascript:</div>
     <div>Coming Soon !</div>
 </div>
 <div class="description">
     <div>Catchphrase:</div>
     <div class="description-content">
         <div>«</div>
         <div><i>Bientôt !</i></div>
         <div>»</div>
     </div>
</div>
 <article class="footer">
     <a title="Previous" href="#Menu"> <svg id="svg_left" width="40" height="40">
         <line x1="30" y1="5" x2="10" y2="20" 
             style="stroke:white; stroke-linecap:round; stroke-width:3"  />
         <line x1="10" y1="20" x2="30" y2="35" 
             style="stroke: white; stroke-linecap:round; stroke-width:3"  />
     </svg> </a>
     <a title="Next" href="#Astrid"> <svg id="svg_right" width="40" height="40">
         <line x1="10" y1=5 x2="30" y2="20" 
             style="stroke:white; stroke-linecap:round; stroke-width:3"  />
         <line x1="30" y1="20" x2="10" y2="35" 
             style="stroke: white; stroke-linecap:round; stroke-width:3"  />
     </svg> </a>
 </article>
 </article>`

}